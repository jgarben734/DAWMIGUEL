import java.util.Scanner;

public class Ejercicio03 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner (System.in);
		System.out.println("Muestra el sueldo actual: ");
		
		double sueldo = scan.nextDouble();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
