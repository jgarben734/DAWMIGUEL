import java.util.Scanner;

public class Ejercicio01 {

	public static void main(String[] args) {
		
		System.out.println("  MENÚ PRINCIPAL \n1- Módulo de Programación    \n2- Módulo de Lenguaje de Marcas   \n0- Resumen y salida del programa");
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Introduce un valor: ");
		
		int num1 = scan.nextInt();
		int num2 = scan.nextInt();
		
		
			
	
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
